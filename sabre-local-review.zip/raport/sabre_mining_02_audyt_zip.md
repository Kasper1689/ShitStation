# Sabre Mining Mk I–III — audyt ZIP i etap poprawki zasilania

Archiwum z polecenia rozpakowano wyłącznie do `/tmp/sabre-review`, po sprawdzeniu nazw wpisów. Nie uruchomiono patchera, generatora ikon ani skryptów pobierających pliki. Stan przed pracą: gałąź `work`, HEAD `1cda8377047e083e002b30bc1037b58a02dbf6ff`, jedyny plik nieśledzony: wcześniejszy `raport/sabre_mining_01_analiza.md`.

## Ryzyko patchera

`apply_sabre_mining_mki_iii_mesons.py` w trybie `--apply` przepisuje całe siedem plików przez `write_text()`, następnie kopiuje DMI. Sprawdza wybrane kotwice tekstowe i obecność poprzedniej implementacji, ale nie sprawdza `git status`, nie tworzy kopii bezpieczeństwa i nie zapisuje wszystkich plików atomowo. Nie wolno stosować go automatycznie na zmienionym checkoutcie. Tu go nie zastosowano.

## Fragmenty przydatne i rozbieżności

| Fragment ZIP | Ocena względem aktualnego API i specyfikacji |
| --- | --- |
| Typ `secondary/utility/mining_module` i podtypy tier2/tier3 | Właściwy istniejący slot; nazwy i układ parametrów nadają się do wykorzystania. |
| Koszty skanu 50/75/100 i magnesu 250/350/500 | Zgodne z poleceniem, lecz `charge <= cost` odrzuca dokładnie wystarczający ładunek. Wynik `use_power()` także jest błędnie interpretowany. |
| Skan przez `scan_state` mineralnego turfu | Dobry wzorzec bez whitelisty złóż. Natomiast przekazywanie `scan_range * 2 + 1` do `mineral_scan_pulse()` podwaja promień: `getviewsize()` już przelicza liczbowy promień na szerokość. |
| `spawn(0)` i istniejący `mineral_scan_pulse()` | Skan śpi pomiędzy pierścieniami i nie ma kontroli odłączenia modułu. Nie spełnia wymogu anulowania pracy i usuwania tylko własnych efektów. |
| Mk II przyciąga przez `throw_at()` poza sąsiednią kratką | Sprzeczne z poleceniem: Mk II i III muszą używać `Move()`, bez rzucania. |
| `deposit_mining_ore()` | Używa `forceMove()`, nie `Move()`. Koordynaty skrzyni są zakodowane na sztywno; trzeba odnaleźć rzeczywistą skrzynię w połączonym wnętrzu i sprawdzać jej aktualną lokalizację. |
| Whitelista `metal_ore_types` | Zbędna globalna lista; ogranicza Mk I do wybranych typów. Nie jest potrzebna do skanowania i nie powinna być podstawą wykrywania wszystkich złóż. |
| Mesony z `REF(src)` i `TRAIT_MESON_VISION` | Właściwe źródło traita i API `update_sight()`. ZIP obejmuje jednak wszystkie Sabre, zamiast wyłącznie Mining. |
| `if(!.) return` po `stop_piloting()` | Korekta pierwotnej oceny audytu: pełna procka bazowa zwraca TRUE na końcu ścieżki dla załogi. Sam ten warunek ZIP nie jest potwierdzonym błędem. W docelowym kodzie cleanup sprawdza rzeczywisty stan pilota po wywołaniu rodzica. |
| Receptury trzech modułów | Można wykorzystać deklaracje przedmiotów i materiały, ale ZIP pomija `DEPARTMENTAL_FLAG_MUNITIONS`, wymagany przez istniejący techfab amunicji. |
| Przypięcie receptur do trzech istniejących węzłów | Zgodne: wyłącznie rozszerzenie `design_ids`. Bez zmian funkcjonalnych konsol asteroid i bez zmiany ich upgrade'ów. |
| Testy Pythona ZIP | Sprawdzają tekst wygenerowany przez patcher; nie są kompilacją ani testem działania DM. Część asercji utrwala rozwiązania sprzeczne ze specyfikacją. |

## Zweryfikowane API i bilans

- `code/controllers/subsystem/processing/obj.dm`: `SSobj.wait = 2 SECONDS`.
- `processing/processing.dm`: subsystem przekazuje `wait * 0.1` jako `delta_time`; ship loadout przekazuje je swoim komponentom (`_fighters.dm:966–969`).
- `engine/process()` ignoruje `delta_time` i przy RPM > 3000 dodaje `500 * tier` na cykl: nominalnie 250/500/750 jednostek na sekundę przy domyślnym interwale, bez gwarancji tempa czasu rzeczywistego przy obciążeniu. Nie zmieniono silnika ani akumulatorów.
- `battery/use_power()` odrzuca wyłączony akumulator; odejmuje ładunek, ogranicza go, wyłącza baterię i uruchamia caution przy zerze; zwraca **FALSE również po poprawnym zużyciu ostatniej porcji**. Trzeba osobno sprawdzać wystarczający ładunek przed poborem.
- Istniejący techfab to `/obj/machinery/rnd/production/techfab/department/munitions` w `nsv13/code/modules/research/machinery/departmental_protolathe.dm`; obsługuje PROTOLATHE i kategorię `Ship Components` przez typ bazowy.
- `getviewsize()` w `code/__HELPERS/view.dm` przyjmuje liczbę jako promień albo tekstowy rozmiar `WxH`. Widok pilota jest oparty na zdalnym oku (`overmap/camera.dm`), więc sam `world.view` nie wystarcza do Mk III.

## Wykonana niezależna poprawka przecinaka

Zmieniono tylko istniejące procki 217-A w `nsv13/code/modules/overmap/fighters/modules/utility_modules.dm`: null-safe odczyt loadoutu; sprawdzanie włączenia baterii i przecinaka przy liczeniu dostępnych strzałów oraz strzale; pobór przez istniejące `use_power()` po sprawdzeniu dostępnego ładunku. Ostatni strzał nadal działa. Laserów, silnika i baterii nie zmieniono. Koszt 2500 pozostawiono na tym niezależnym etapie — zmiana na 1000 należy do etapu Mining.

Nie dodano osobnego pliku z ponownymi definicjami tych samych proców: byłoby to mniej bezpieczne niż niewielka edycja istniejącej implementacji. Poprawkę udokumentowano w `aquila/LEGACY_OVERRIDES.md`. Dodano prawdziwy test DM `aquila_plasmacutter_power` w osobnym pliku z include pod `UNIT_TESTS`: sprawdza strzał na zwykłym small craft bez modułów Mining, brak/wyłączenie baterii, niewystarczający ładunek, wyłączenie przecinaka, dokładnie jeden strzał, alarm wyczerpania i demontaż.

## Punkt wymagający decyzji

**Rozstrzygnięte w kolejnym poleceniu:** użytkownik potwierdził zamierzoną bezwładność `throw_at()` w Mk I i Mk II. Demontaż blokuje kolejne impulsy; nie zatrzymuje rozpoczętego lotu. Poniższy opis dokumentuje wcześniejszą przyczynę wstrzymania, nie aktualny blocker.

Polecenie wymaga dla Mk I „istniejącej, bezpiecznej mechaniki przyciągania”. W przejrzanych systemach rud istnieją kolektory Ripley i mining drone, ale przenoszą przez `forceMove()`; nie ma znalezionego magnesu rud realizującego opisane przyciąganie. ZIP stosuje rzuty `throw_at()`, których dalszy lot nie jest anulowany przez odłączenie modułu. Zapytano o zgodę na standardowe przyciąganie krokami przez `step_towards()/Move()` bez rzucania. Funkcje Mining pozostają wstrzymane do rozstrzygnięcia tego punktu, zgodnie z poleceniem użytkownika, by nie implementować mechaniki na podstawie domysłów.

## Weryfikacja i dalsze testy

Nie zainstalowano zależności. Lokalnie brak DreamMaker i dreamchecker; test DM został napisany, ale **nie został wykonany**, podobnie jak kompilacja i testy gry. `git diff --check` jest kontrolą formatowania diffu, nie składni DM.

Po udostępnieniu istniejącego toolchainu: uruchomić `aquila_plasmacutter_power` w konfiguracji UNIT_TESTS, następnie przebudować zwykły `.dmb`. Ręcznie porównać wyłączony akumulator, ładunek tuż poniżej kosztu, dokładnie równy kosztowi oraz dwa kolejne strzały. Ostatni skuteczny strzał ma ustawić zero, wyłączyć baterię i uruchomić caution. Sprawdzić zwykłe Sabre i Mining. Nie dodano komory testowej (to bugfix), nie zmieniono wiki ani nie przebudowano TGUI.
