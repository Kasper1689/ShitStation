# Widzenie kamery, mesony i współpraca skanerów

Aktualizacja lokalnej implementacji na polecenie użytkownika: usunięcie dodatkowych mesonów, bez publikacji i pobierania zależności.

## Wykonane uproszczenie

Z `aquila/code/modules/overmap/sabre_mining.dm` usunięto grant/revoke traita mesonów, przechowywanie pilota i hooki przecinaka dotyczące optyki, hook rozpoczęcia pilotażu oraz nadpisanie `overmap_observer/update_remote_sight()`. Zakończenie pilotażu zachowuje tylko sprzątanie oznaczeń skanera. Koszt strzału 1000 i niezależny bugfix zasilania pozostają.

Z `FighterControls.tsx` usunięto przycisk przecinaka/mesonów oraz powiązane dane i akcję backendu. Przywrócono całkowicie bazową ścieżkę widzenia kamery dla Sabre Mining, niezależną od zamontowania przecinaka. Nie zmieniono gogli ani wspólnego systemu widzenia.

## Dokładne różnice odczytane z kodu

| Cecha | Domyślna kamera statku | Zwykłe gogle mezonowe przy normalnym widzeniu postaci |
| --- | --- | --- |
| Teren i ściany przez przeszkody | `sight = SEE_TURFS \| SEE_BLACKNESS` | `vision_flags = SEE_TURFS`, dodawane do obecnych flag widzenia |
| Oświetlenie | Kamera nie ustawia `lighting_alpha`; pozostaje wartość przygotowana wcześniej przez postać/oczy | Ustawiają limit `LIGHTING_PLANE_ALPHA_MOSTLY_VISIBLE`, czyli 192; zmniejszają zaciemnienie |
| `see_in_dark` | Wymuszone 2 | Bazowo 2; końcowe widzenie może zachować wyższą wartość z innych źródeł |
| Niewidzialność | Wymuszone `SEE_INVISIBLE_LIVING` (25) | Bazowo również 25, uwzględniane z resztą wyposażenia/oczu |
| Kolor | Sama kamera nie dodaje koloru | Gogle nadają filtr `lightgreen`; to odrębny mechanizm od flag widzenia |
| Łączenie z innymi zdolnościami wzroku | Kamera zwraca TRUE i kończy `carbon/update_sight()` przed dalszą obsługą gogli i traits | Normalna ścieżka dodaje właściwości gogli, traits, oczu itd. |
| Rozpoznanie rodzaju złoża | Nie | Nie — potrzebne są oznaczenia skanera |
| Moby/przedmioty przez ściany | Sama kamera nie dodaje `SEE_MOBS` ani `SEE_OBJS` | Same mesony również nie dodają tych flag |

Nie są to zatem identyczne tryby widzenia, ale wspólne `SEE_TURFS` zapewnia potrzebny tutaj efekt oglądania struktury terenu. Kamera nie jest automatycznie odpowiednikiem noktowizyjnych mesonów (`/meson/night` ma `darkness_view = 8` i lighting alpha 128).

Źródła:

- `code/game/machinery/computer/camera_advanced.dm:175` — bazowe `remote/update_remote_sight()`.
- `code/modules/mob/living/carbon/carbon.dm:525–585` — przygotowanie widzenia i wcześniejszy return po kamerze.
- `code/modules/clothing/glasses/_glasses.dm:58–93` — zwykłe i noktowizyjne mesony.
- `code/__DEFINES/lighting.dm:83–86`, `code/__DEFINES/sight.dm:5` — wartości stałych.
- `nsv13/code/modules/overmap/camera.dm:108–133` — oko kamery używane przez pilota.

## Skaner górnika i znaleziony konflikt

Mesony/kamera pokazują teren, natomiast skaner górnika dodaje czasowe oznaczenia rodzaju złóż według `mineral.scan_state`. To różne mechanizmy, które mogą działać razem. Powrót do oryginalnej kamery nie zmienia `scan_state`, kosztu skanu ani research.

Znaleziono jednak drobny konflikt między **dwoma skanerami** w poprzedniej implementacji: `mineral_scan_pulse()` (`mineral_scanner.dm:100–103`) odnajduje pierwsze `/obj/effect/temp_visual/mining_overlay` na złożu i usuwa je przed odświeżeniem znacznika. Ponieważ Sabre używało tego samego typu obiektu, ręczny/automatyczny skaner górnika mógł skasować jego oznaczenie.

**Na kolejne polecenie użytkownika cofnięto tę poprawkę.** Sabre ponownie używa bezpośrednio istniejącego `/obj/effect/temp_visual/mining_overlay`; usunięto jego osobny odpowiednik i test wymagający rozdzielenia typów. Dzięki temu przyszłe zmiany wyglądu, zanikania i innych właściwości wspólnego oznaczenia obejmą również Sabre. Mechanika wykonywania skanu Sabre pozostaje odrębna od ręcznego skanera.

Możliwe wzajemne odświeżanie/usuwanie oznaczeń zaakceptowano. Ewentualna izolacja będzie rozważana dopiero po potwierdzeniu problemu w grze i uzyskaniu zgody użytkownika. Dodatkowe poprawki wykraczające poza zleconą zmianę wymagają wcześniejszego pytania.

## Weryfikacja i dalsze sprawdzenie

Zmiany tego etapu: `sabre_mining.dm`, `aquila_sabre_mining.dm`, `FighterControls.tsx`, oznaczenie raportu 03 jako historycznego oraz ten raport. Eksport jest odświeżony; najnowszy raport ma numer 04.

Kontrole statyczne obejmują diff, repozytoryjne kontrole grep/include, brak pozostawionych hooków mesonów i zgodność źródeł bazowej kamery/gogli/skanera z HEAD. Kompilacja BYOND, sześć testów DM, build TGUI i test gry pozostają niewykonane: toolchain nie jest zainstalowany, a pobieranie zależności pozostaje poza zakresem.

Po kompilacji sprawdzić widok Sabre Mining z przecinakiem i bez niego — ma być taki sam. Następnie przeskanować to samo złoże modułem Sabre i skanerem ręcznym, obserwując współdzielone oznaczenia; ewentualną częstotliwość ich wzajemnego zastępowania ocenić w grze. Wykonać `aquila_sabre_mining_scan` oraz pozostałe testy regresji. Przecinak nadal wymaga sprawnego włączonego akumulatora i kosztuje 1000 energii; widzenie nie zależy od jego aktywności.
