# Sabre Mining — analiza lokalnej implementacji

Stan analizy: 2026-11-05. Repozytorium `/workspace/ShitStation`, gałąź `work`, HEAD `1cda8377047e083e002b30bc1037b58a02dbf6ff`.

Przegląd statyczny lokalnych źródeł. Bez instalacji zależności, połączeń z GitHubem, pobierania plików, kompilacji i uruchamiania gry. Jedynym nowym plikiem jest ten raport. Wnioski o wykonaniu wymagają późniejszej walidacji w BYOND; poniżej rozdzielono błędy widoczne w kodzie od zmian zależnych od docelowej mechaniki.

## 1. Obecny przepływ

- `nsv13/code/game/general_quarters/dropship_types.dm:135–183`: typ `/transport/sabre/mining` zmienia ikonę, dostęp i mapę wnętrza. Dziedziczy moduły Sabre, w tym podstawowy akumulator i silnik, zbiornik paliwa tier 2, FTL i zestaw tankowania. Nie deklaruje własnego zestawu `components` ani startowego przecinaka.
- `nsv13/code/modules/overmap/fighters/_fighters.dm:530–552`: inicjalizacja tworzy loadout i montuje komponenty; lista przekazana z budowy może zastąpić zestaw domyślny.
- `code/__DEFINES/nsv13.dm:68–72` oraz `_fighters.dm:908–909`: Sabre ma loadout użytkowy, z jednym slotem głównym użytkowym i jednym pomocniczym użytkowym.
- `nsv13/code/modules/overmap/fighters/modules/utility_modules.dm:2–53`: broń górnicza to montowany przecinak 217-A, zajmujący `HARDPOINT_SLOT_UTILITY_PRIMARY`. Koszt strzału wynosi 2500 ładunku, opóźnienie 0,5 s, seria jeden pocisk, masa 1. Pocisk ma `range = 6`, `mine_range = 7` i dziedziczy 14 obrażeń z `/plasma/adv`.
- `_maps/templates/boarding/sabre_interior_mining.dmm:67–69`: wnętrze zawiera fizyczny górniczy DRADIS. Transport ma `dradis_type = null` (`dropship_types.dm:37`); nie dostaje automatycznie radaru zintegrowanego myśliwca.
- `nsv13/code/modules/research/techweb/all_nsv_nodes.dm:174–182` i `designs/fighter_designs.dm:216–224`: research `fightermining` odblokowuje projekt `r_cutter`, produkowany na protolacie Cargo.

Pliki są włączone do projektu: `nsv13.dme:3724,3961,3984,4037,4050`. W przeszukanym `aquila/code` nie znaleziono nadpisania przecinaka ani akumulatora Sabre; istniejący `fighter_toilet.dm` nie dodaje mechaniki wydobycia.

## 2. Miejsca wymagające poprawy

### A. Przecinak omija stan zasilania i obsługę wyczerpania akumulatora — wysoki priorytet

**Miejsce:** `nsv13/code/modules/overmap/fighters/modules/utility_modules.dm:20–48`.

`get_ammo()` liczy dostępne strzały z `B.charge` bez sprawdzania `B.active`. `fire()` również nie sprawdza stanu akumulatora i wykonuje `B.charge -= charge_to_fire`. Wyłączony, naładowany akumulator nadal zasila tę broń. Ostatni strzał, redukujący ładunek dokładnie do zera, nie wywołuje logiki wyłączenia i alarmu akumulatora.

**Dowód powiązania:** `_fighters.dm:1227–1239` — `use_power()` sprawdza `active`, ogranicza ładunek i obsługuje wyczerpanie. Ogólny `can_fire()` w `weapons/delta_overmap_ship_weapons/firing_checks.dm:101–111` kontroluje dostępność amunicji; ta dla przecinaka ignoruje `active`.

**Zmiana:** spójna kontrola obecności, włączenia i wystarczającego ładunku w ścieżce dostępności oraz strzału; pobór z obsługą wyczerpania. Nie wystarczy mechanicznie zamienić odejmowania na `if(!B.use_power(...))`: obecne API zwraca FALSE także po poprawnym zużyciu ostatniej porcji energii. Trzeba zachować możliwość strzału przy dokładnie 2500 ładunku bez utraty energii na strzał anulowany.

**Powiązany kod:** laser w `_fighters.dm:1764–1793` powiela ten wzorzec. Wspólna poprawka wymaga regresji również dla lasera, ale nie jest konieczna do lokalnej poprawki przecinaka.

### B. Brak zabezpieczeń przy wymontowanych modułach — średni priorytet

**Miejsca:**

- `utility_modules.dm:38–44`: `fire()` odczytuje `B.charge` bez kontroli `B`.
- `_fighters.dm:1403–1405`: silnik przy RPM > 3000 wywołuje `B.give(...)` bez kontroli obecności akumulatora.
- `_fighters.dm:147–153`: panel odczytuje `APU.active` bez kontroli obecności APU.

**Skutek:** możliwe błędy runtime po wymontowaniu modułu lub przy bezpośrednim wywołaniu procki z niekompletnym loadoutem. Normalna ścieżka strzału bez akumulatora jest częściowo chroniona: `get_ammo()` zwraca 0, a wrapper ogranicza serię do dostępnej amunicji (`weapon_datum_types.dm:288–290`). Nie jest to dowód, że zwykłe kliknięcie bez akumulatora zawsze powoduje runtime.

**Zmiana:** dodać lokalne zabezpieczenia i zachowanie dla brakujących modułów. Wymontowanie przez panel jest rzeczywistą funkcją (`_fighters.dm:237–247`), a nie wyłącznie administracyjnym przypadkiem.

### C. Opis ulepszenia radaru wskazuje inne urządzenie — niski priorytet

**Miejsce:** `nsv13/code/modules/mining/asteroid.dm:184–189`.

`/obj/item/mining_sensor_upgrade` opisuje montaż w konsoli magnesu asteroid i przechwytywanie asteroid. Faktyczna obsługa tego przedmiotu jest w `radar.dm:316–328`: ulepsza DRADIS i poziom wykrywania. Magnes używa odrębnych `/obj/item/deepcore_upgrade`.

**Zmiana:** poprawić opis czujnika, zachowując rozdzielenie wykrywania przez radar i przechwytywania przez magnes.

## 3. Moduły i konfiguracja Mining — zmiany zależne od celu

**Miejsca:** `dropship_types.dm:158–179`, `_fighters.dm:927–935,1920–1929`, `modules/refueling_kit.dm:1–16`, `modules/repair_kit.dm:1–8`.

Przecinak, tankowanie i naprawa konkurują o jeden slot główny użytkowy. Montaż przecinaka usuwa poprzedni moduł tego slotu. Ładownia (`modules/cargo_hold.dm:1–19`) jest modułem pomocniczym użytkowym i może współistnieć z przecinakiem. Wariant Mining nie ma własnego automatycznego zbierania rudy w przejrzanej definicji; obecna ładownia służy do ładowania obiektów (`cargo_hold.dm:21–28`).

Jeżeli Mining ma od początku dysponować przecinakiem, miejscem zmiany jest jego własny zestaw `components`, a nie domyślny zestaw wszystkich transportowców. Jeżeli ma jednocześnie tankować, naprawiać i strzelać, potrzebna będzie świadoma zmiana modelu slotów i wyboru narzędzi; obecne rozwiązywanie broni obsługuje primary/secondary (`_fighters.dm:1633–1652`). Samo dopisanie komponentów do listy nie zapewni ich współistnienia.

Budowa ramy użytkowej daje zwykłe Sabre (`fighters/construction.dm:71–78`), a finalizacja korzysta z `output_path` i listy typów części (`508–520`). Projekt `utility_frame` (`fighter_designs.dm:33–41`) nie daje osobnej ramy Mining. To miejsce ewentualnej zmiany, jeśli wariant Mining ma być osobno budowany; obecny stan nie jest sam w sobie potwierdzonym błędem.

Sabre Mining jest już umieszczony m.in. w `_maps/map_files/Shrike/Shrike1.dmm:1195`, `Mining/nsv13/Rocinante.dmm:465`, `Atlas/atlas.dmm:16863`. Zmiana definicji typu wpłynie na te instancje. Nie ma potrzeby masowej edycji map w celu samej zmiany domyślnego loadoutu.

## 4. Radar — działająca osobna ścieżka, nie brak implementacji

**Miejsca:** `radar.dm:179–199,212–221,316–328,385–397`; mapa wnętrza `sabre_interior_mining.dmm:67`.

Górniczy DRADIS ma `show_asteroids = TRUE` i dziedziczy poziom 1. Ulepszenia podnoszą go do 2 lub 3. Filtr porównuje `asteroid.required_tier` z `mining_sensor_tier`, więc ukrywanie cenniejszych asteroid bez ulepszenia jest zamierzoną bramką. `set_position()` rejestruje konsolę jako `OM.dradis`; przycisk w panelu wywołuje `dradis?.ui_interact(usr)` (`_fighters.dm:346–347`).

`targeting_sensor` z konstrukcji (`fighters/construction.dm:15`) nie jest tym samym co fizyczny górniczy DRADIS i jego przedmiotowe ulepszenia. Nie należy podnosić tieru radaru przez samą wymianę tego elementu konstrukcyjnego.

Jeżeli planowane są montowane moduły radaru, trzeba określić relację między slotem `HARDPOINT_SLOT_RADAR`, konsolą wnętrza i jej ulepszeniami; obecnie są to różne mechanizmy. Dodanie równocześnie radaru zintegrowanego i konsoli może nadpisywać `OM.dradis` — wymaga sprawdzenia cyklu ładowania wnętrza. Nie stwierdzono w tym przeglądzie, że aktualna konsola nie łączy się ze statkiem.

Istotne dla energii: obszar wnętrza `/area/dropship` ma `requires_power = FALSE` (`game/general_quarters/dropship.dm:51–57`). Radar wnętrza nie ma tutaj poboru z akumulatora myśliwca. Powiązanie działania radaru z akumulatorem byłoby nową mechaniką, wymagającą odrębnego projektu i testów.

## 5. Energia i wydajność wydobycia

**Miejsca:** `_fighters.dm:1208–1254,1389–1407,1535–1574`, `utility_modules.dm:10,18`.

- Akumulatory tier 1/2/3 mają 10000/20000/40000 ładunku: bez doładowania i innych odbiorników odpowiada to 4/8/16 strzałom przecinaka.
- Silnik przy RPM > 3000 dodaje `500 * tier` na wywołanie `process()`. To nie jest jawnie stawka na sekundę: procka ignoruje `delta_time`. Bez pomiaru częstotliwości przetwarzania nie należy podawać z tego nominalnego czasu ładowania.
- APU w przejrzanym kodzie rozkręca silnik; nie zawiera własnego `B.give()`. Nie należy przypisywać mu bezpośrednio mocy ładowania akumulatora.
- Zwiększenie `maxcharge` zwiększa zapas strzałów, a zwiększenie tieru silnika zmienia też prędkość i ciąg (`_fighters.dm:1449–1455`). Jeżeli celem jest wyłącznie szybsze ładowanie, zmiana silnika ma skutki poza górnictwem.

**Miejsca ewentualnej korekty bilansu:** koszt strzału i cooldown w `utility_modules.dm`, generacja w `engine/process()`, parametry akumulatorów. Zmiany globalne obejmą również myśliwce bojowe i inne Sabre; dla bilansu Mining preferowana jest najwęższa możliwa zmiana. Normalizacja `delta_time` wymaga sprawdzenia dotychczasowego tempa, żeby nie zmienić nieświadomie całego bilansu.

## 6. „Działo plazmowe” — dwa różne systemy

Broń Sabre to `/obj/item/fighter_component/primary/plasmacutter` z `modules/utility_modules.dm`. Duży `/obj/machinery/ship_weapon/plasma_caster` z `overmap/weapons/plasma_gun.dm:1–58` jest osobnym działem okrętowym MPAC, używa rdzeni i gazowej plazmy. Nie jest modułem przecinaka Sabre i nie wymaga zmian do poprawy jego poboru energii.

Przecinak dziedziczy zachowanie pocisku z `code/modules/projectiles/projectile/special/plasma.dm:14–28`. Wydobycie następuje dla `ismineralturf(target)` i wywołuje `gets_drilled(firer)`, z przedłużaniem zasięgu na skałach. Asteroida na overmapie (`nsv13/code/modules/mining/asteroid.dm:63–116`) ma osobne wnętrze mineralne. Nie znaleziono w analizowanej ścieżce implementacji zamiany trafienia ikony asteroidy przez przecinak w wydobycie jej zasobów. Dodanie takiej funkcji wymaga pracy przy asteroidzie i obsłudze trafienia, a nie tylko zwiększenia `mine_range`.

## 7. Research i produkcja

**Konkretne miejsca:**

| Obszar | Plik i linie | Aktualne zachowanie / zakres ewentualnej zmiany |
| --- | --- | --- |
| Odblokowanie przecinaka | `nsv13/code/modules/research/techweb/all_nsv_nodes.dm:174–182` | `fightermining`, 1500 punktów; wymagania `fighter_tier1`, `adv_mining`, `adv_plasma`; jedyny projekt `r_cutter`. Tu zmienia się dostępność technologii. |
| Produkcja przecinaka | `nsv13/code/modules/research/designs/fighter_designs.dm:216–224` | PROTOLATHE, Cargo, 10000 żelaza + 2000 szkła + 5000 plazmy. Tu zmienia się receptura i dostęp działów. |
| Części i ich ulepszenia | `all_nsv_nodes.dm:114–142` | Trzy osobne poziomy części, w tym baterii i silników. Nie są ulepszeniami samego przecinaka. |
| Ulepszenia wykrywania asteroid | `nsv13/code/modules/mining/asteroid.dm:5–61` | Osobne węzły `mineral_nonferrous` (7500) i `mineral_exotic` (12500), projekty `asteroidscanner`/`asteroidscanner2`, Cargo i Science. |
| Wspólne wymagania | `code/modules/research/techweb/all_nodes.dm:322–330,767–774` | `adv_mining` już wymaga `adv_plasma`; powtórzenie w `fightermining` jest zależnością redundantną, nie potwierdzonym błędem blokującym. |

Nie znaleziono tierów przecinaka ani dedykowanego górniczego generatora w przejrzanej ścieżce. Jeżeli mają zostać dodane, potrzebne są zarówno typy modułów, jak i unikalne projekty oraz przypisanie ich identyfikatorów do węzłów research. Sam wpis do węzła nie tworzy przedmiotu. Aktualne wymaganie Cargo dla produkcji przecinaka jest jawne; nie ma podstaw, by bez ustalonego celu uznać brak dostępu innych działów za błąd.

## 8. Panel i późniejsza walidacja

`tgui/packages/tgui/interfaces/FighterControls.tsx:96–104` pokazuje ładunek baterii z jednostką `W`, choć backend przekazuje ilość ładunku, nie tempo poboru. To miejsce korekty prezentacji jednostek po ustaleniu ich konwencji. `119–131` pokazuje amunicję, `219–223` otwiera DRADIS. Backend danych jest w `_fighters.dm:124–126,150–156,179–198`.

Po późniejszej implementacji potrzebne są testy: brak/wyłączenie akumulatora; 2499/2500/2501 ładunku; ostatni strzał i alarm; odłączenie APU/akumulatora przy otwartym panelu i pracującym silniku; wymiana przecinaka na tankowanie/naprawę; ładowanie tierów silnika; radar tier 1/2/3 i brak zasilania; odblokowanie i produkcja projektu; trafienie skały mineralnej oraz osobno asteroidy na overmapie. Interakcje strzału należy sprawdzić w obu trybach sterowania.

Nowe testy logiki powinny trafić do `aquila/code/modules/unit_tests/`, z dołączeniem w `aquila/aquila.dm`. Zgodnie z zasadami projektu nowe rozszerzenia należy umieszczać w `aquila/`; powyższe ścieżki źródłowe wskazują punkty integracji, nie zalecenie szerokiej edycji upstreamu. Core hook wymaga minimalnego zakresu i wpisu do `aquila/LEGACY_OVERRIDES.md`.

Nie przebudowano `.dmb` ani TGUI; nie dodano testów, zestawu komory testowej ani wpisów wiki, ponieważ to przegląd bez zmian mechaniki. Priorytet wdrożenia: A (spójność zasilania), B (odporność na brak modułów), C (opis czujnika). Pozostałe punkty wymagają ustalenia docelowych funkcji i balansu przed zmianą kodu.
