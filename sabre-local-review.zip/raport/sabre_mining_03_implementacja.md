# Sabre Mining Mk I–III — implementacja lokalna

**Raport historyczny poprzedniego etapu.** Na kolejne polecenie użytkownika usunięto funkcję mesonów i przywrócono oryginalny widok kamery. Aktualny stan i poprawkę współpracy skanerów opisuje `sabre_mining_04_widzenie_i_skanery.md`; poniższe opisy optyki nie dotyczą już bieżącej implementacji.

Stan: 2026-11-05, baza `1cda8377047e083e002b30bc1037b58a02dbf6ff`, gałąź `work`. Zmiany nie są commitowane ani publikowane. Nie pobierano zależności i nie uruchamiano patchera z ZIP.

## Działanie

Fabryczne wyposażenie pozostaje bez zmian. Trzy opcjonalne fizyczne moduły zajmują istniejący slot utility secondary, zastępując np. ładownię. Instalacja jest dopuszczona tylko na `/transport/sabre/mining`; odrzucona próba nie usuwa dotychczasowego modułu.

| Moduł | Skan | Koszt skanu | Magnes | Koszt impulsu | Receptura w istniejącym węźle |
| --- | --- | --- | --- | --- | --- |
| Mk I | promień 12 kratek | 50 | promień 3, rudy metaliczne jak w ZIP | 250 | `fightermining` |
| Mk II | promień 20 kratek | 75 | promień 3, wszystkie typy rud | 350 | `mineral_nonferrous` |
| Mk III | prostokąt aktualnego widoku pilota, względem jego rzeczywistego oka kamery | 100 | promień 5, wszystkie typy rud | 500 | `bagofholding` |

Skan jest ręczny, z istniejącego panelu FighterControls. Korzysta z `scan_state` mineralnych turfów — bez whitelisty złóż, również dla bananium i gibtonitu. Odstępy między skanami 4/3/2 sekundy są zachowane z ZIP. Moduł przechowuje własne oznaczenia i usuwa je przy wymianie, demontażu, wyłączeniu lub zakończeniu pilotażu. Nie kasuje cudzych oznaczeń. Nie ma śpiącej procki ani odroczonych pierścieni skanu kontynuujących pracę po demontażu.

**Korekta specyfikacji potwierdzona przez użytkownika:** Mk I i Mk II używają impulsów `throw_at()` dla odleglejszych rud. Nie przerywają rozpoczętego lotu po demontażu; sprawdzają stan modułu przed następnym impulsem i nie popychają ponownie przedmiotu z aktywnym `throwing`. Ruda przy kadłubie jest przenoszona przez `Move()`, a do skrzyni trafia również przez `Move()`. Mk III używa bezpośredniego `Move()` do skrzyni i nie rzuca rudą.

Zachowano ochronę kryształów bluespace z ZIP: Mk II pobiera je przez Move z sąsiedniej kratki lub kadłuba, ale nie rzuca nimi z większej odległości, ponieważ ich `throw_impact()` zużywa kryształ. Mk III zbiera je w pełnym zasięgu 5. Mk I zachowuje z ZIP magnetyczną klasyfikację metalicznych rud, obejmującą bananium; nie jest to ograniczenie skanera.

Skrzynia jest odnajdywana w aktualnym połączonym wnętrzu, bez sztywnych współrzędnych. Brak lub usunięcie skrzyni blokuje zbieranie bez poboru energii. Nie jest tworzona nowa skrzynia ani nowa konsola. Ładunek spoza właściwego wirtualnego poziomu, zawartość innych kontenerów, przedmioty zakotwiczone i już lecące są pomijane.

Receptury są dopisane przez wzorzec `New()` istniejących węzłów, w modularnym pliku Aquili. Nie zmieniono kosztów/prerekwizytów tych węzłów, kodu konsoli asteroid, radaru wnętrza ani ich ulepszeń. Projekty mają flagę Munitions, więc są dostępne w istniejącym techfabie amunicji, oraz Cargo/Engineering jak w ZIP. Zachowano materiały receptur z archiwum.

## Przecinak: oddzielny bugfix i funkcje Mining

**Niezależny bugfix:** minimalna edycja istniejących `get_ammo()`, `get_max_ammo()` i `fire()` 217-A, bez powtórnego definiowania tych proców. Sprawdza obecność/włączenie akumulatora i przecinaka. Pobór używa istniejącego `use_power()` po sprawdzeniu wystarczającego ładunku. Dokładnie wystarczający ładunek daje ostatni strzał, zeruje i wyłącza akumulator oraz uruchamia caution. Nie zmieniono laserów ani pozostałych broni. Samodzielny patch tego bugfixu nadal ma pierwotny koszt 2500 i nie wymaga funkcji Mining.

**Etap Mining:** w pliku modularnym koszt przecinaka zmniejszono do 1000; cooldown pozostaje 0,5 s. Aktywny przecinak nadaje wyłącznie pilotowi Sabre Mining trait `TRAIT_MESON_VISION` ze źródłem `REF(src)`. Montaż, wejście/wyjście pilota, wymiana, toggle i Destroy aktualizują widzenie oraz usuwają tylko to źródło.

Istotna korekta względem ZIP: ogólna zdalna kamera wymuszała `SEE_TURFS` i zwracała TRUE, pomijając traits. Wąska implementacja `overmap_observer/update_remote_sight()` tylko dla pilota Mining pozwala dokończyć istniejący carbon `update_sight()`, który uwzględnia oczy, gogle i wszystkie źródła traits. Inne statki i obserwatorzy zachowują dotychczasową ścieżkę. Sam stan aktywności przecinaka kontroluje optykę; mesony nie mają dodatkowego poboru energii.

Hook zakończenia pilotażu zachowuje domyślne `eject_mob = FALSE` transportowca, zamiast kopiować `TRUE` ze zwykłego myśliwca/ZIP. Wyjście z kamery nie wyrzuca załogi z wnętrza.

## Energia — sprawdzony kod, bez zmiany silnika

`SSobj.wait` wynosi domyślnie 2 sekundy; `ship_loadout/process(delta_time)` przekazuje delta komponentom. Silnik ignoruje delta i dodaje 500 × tier na wywołanie przy RPM > 3000: nominalnie 250/500/750 jednostek na sekundę. To odczyt implementacji, nie pomiar działającego serwera; obciążenie i zmiana interwału mogą zmienić rzeczywiste tempo.

Odstęp magnesu 1,6 s jest zachowany z ZIP i kontrolowany przez `world.time`. Przy standardowym SSobj impulsy występują nominalnie co 2 s, tylko gdy są cele i skrzynia: 125/175/250 energii/s. Skan pobiera energię tylko po użyciu przycisku, bez biernego poboru 200 odziedziczonego po utility secondary. Ostatni impuls przy dokładnym stanie energii jest dozwolony. Przecinak przy ciągłym ogniu może zużywać 2000/s, więc korzysta z bufora akumulatora; nie jest stale podtrzymywany przez podstawowy silnik. Nie zastosowano wcześniejszych założeń 625/1250/1875 energii/s i nie zmieniono tempa ładowania.

W silniku/APU dodano wyłącznie null guards dla wymontowanego akumulatora/silnika, a w panelu dla wymontowanego APU. Nie zmieniają one stawek, pojemności, startowego loadoutu ani algorytmu ładowania.

## Pliki

- `nsv13/code/modules/overmap/fighters/modules/utility_modules.dm` — niezależny bugfix 217-A.
- `aquila/code/modules/unit_tests/aquila_plasmacutter_power.dm` — niezależny test regresji; zwykły nieminingowy fixture z istniejącym loadoutem utility. Bazowy loadout myśliwca nie obsługuje utility primary/secondary, więc nie użyto go błędnie do instalacji przecinaka.
- `aquila/code/modules/overmap/sabre_mining.dm` — trzy moduły, obsługa panelu, mesony, ograniczony hook kamery, receptury i rozszerzenia istniejących węzłów.
- `aquila/code/modules/unit_tests/aquila_sabre_mining.dm` — pięć testów DM dla sprzętu/mesonów, skanu, kolektora, bezwładności i research.
- `aquila/icons/obj/sabre_mining_modules.dmi` — niezmieniony zasób z ZIP; trzy stany `mining_mk1/2/3`, po 32×32. Nie generowano nowych sprite'ów.
- `nsv13/code/modules/overmap/fighters/_fighters.dm` — hook `can_install()` przed zdjęciem starego wyposażenia i trzy zabezpieczenia null.
- `tgui/packages/tgui/interfaces/FighterControls.tsx` — przyciski istniejącego panelu: moduł, skan, magnes, przecinak/mesony.
- `aquila/aquila.dm` — include implementacji i testów pod UNIT_TESTS; bez zmian w głównym `.dme`.
- `aquila/LEGACY_OVERRIDES.md` — dokumentacja dotkniętych miejsc core.
- `raport/sabre_mining_02_audyt_zip.md` i ten raport — audyt, korekty i instrukcje. Wcześniejszy raport 01 zachowany.

## Weryfikacja

Wykonano z wynikiem pozytywnym:

- `git diff --check`.
- `bash tools/ci/check_filedirs.sh nsv13.dme`.
- `bash tools/ci/check_grep.sh` — brak błędów.
- Kontrolę braku powtórnych definicji nowych proców na tych samych typach, pojedynczych include i położenia include testów pod UNIT_TESTS.
- Kontrolę identyfikatorów trzech receptur, przypisania do wskazanych istniejących węzłów i zgodności nazw akcji TGUI/backend.
- Porównanie z HEAD: fabryczny loadout, radar, konsola asteroid, wspólny skaner i źródłowe pliki istniejących tech nodes pozostały niezmienione.
- Odczyt metadanych DMI, wymiarów i nazw stanów oraz zgodność bajtów z dostarczonym zasobem.

**Nie wykonano:** kompilacji DreamMaker, uruchomienia sześciu testów DM, testów gry, TypeScript i przebudowy TGUI. W bieżącym środowisku nie ma dostępnego DreamMaker/dreamchecker, `.pnp.cjs` ani zainstalowanego zestawu zależności TGUI. Nie uruchamiano build wrapperów instalujących zależności i nie próbowano obejść ograniczeń sieci. Kontrole tekstowe nie dowodzą poprawności kompilacji DM ani zachowania gry.

## Test w grze po lokalnej kompilacji

1. Użyć BYOND 516.1688 i istniejącego, już zainstalowanego toolchainu projektu. Przebudować TGUI i DM. Dla testów regresji użyć standardowej konfiguracji CI z `CIBUILDING`/UNIT_TESTS; sprawdzić wyniki `aquila_plasmacutter_power` oraz pięciu `aquila_sabre_mining_*`. Następnie przebudować zwykły `.dmb`, bez UNIT_TESTS. Nie pozostawiać testowego świata jako zwykłego serwera.
2. Na fabrycznym Mining potwierdzić brak nowych modułów. Zbadać kolejno `fightermining`, `mineral_nonferrous`, `bagofholding` i sprawdzić właściwe receptury w techfabie amunicji. Węzły nie mają nowych zależności między sobą — zachowano ich obecną progresję.
3. Zainstalować każdy Mk w utility secondary; sprawdzić zastąpienie ładowni i odrzucenie instalacji na zwykłym Sabre/myśliwcu bez utraty starego modułu. Obsługiwać moduł przez istniejący panel FighterControls.
4. Umieścić bananium i inne złoża na granicach 12/13 oraz 20/21 kratek. Dla Mk III zmienić zoom/widok kamery i potwierdzić cały aktualny prostokąt widoku, również przy krawędzi mapy.
5. Dla Mk I/II obserwować pojedynczy impuls i dalszy lot. W trakcie lotu wyłączyć lub zdjąć moduł: lot może trwać, lecz nie mogą pojawić się następne impulsy ani pobór. Sprawdzić również wymianę Mk, zanik oznaczeń starego skanu i pozostanie cudzych oznaczeń.
6. Mk III: ruda i kryształ bluespace w promieniu 5 trafiają bez rzucania do rzeczywistej skrzyni. Usunąć/przenieść skrzynię poza wnętrze, zdjąć baterię i secondary: brak runtime i dalszego poboru. Mk II: kryształ sąsiedni przechodzi przez Move, odleglejszy nie jest rzucany.
7. Przecinak: akumulator wyłączony, pusty, 999/1000/1001 energii; dokładnie ostatni strzał i caution. Mesony tylko dla pilota Mining z aktywnym przecinakiem, znikające po toggle/demontażu/wyjściu. Sprawdzić zmianę pilota, zniszczenie przecinaka oraz zachowanie mesonów z gogli/innych traits.
8. Sprawdzić strzał i obsługę w obu trybach sterowania. Sprawdzić demontaż baterii/APU/silnika przy otwartym panelu i pracującym silniku.

Nie dodano zestawu komory testowej ani wpisu wiki: na wyraźne polecenie zakres ograniczono do minimalnej implementacji do testów, bez dodatkowego contentu i publikacji. `.dmb` i bundle TGUI nie są przebudowane. Zmiany w core są udokumentowane; nie ma niezwiązanych zmian w innych systemach.

## Eksport

Pliki eksportu znajdują się w `/workspace/scratch/sabre-mining-review/`. ZIP zawiera samodzielny patch 01 bugfixu zasilania, patch 02 funkcji Mining, pełny patch obejmujący oba etapy i zasób binarny oraz raporty. Wybrać **pełny patch albo serię 01→02**, nie oba warianty naraz. Na kopii bazy wskazanej na początku najpierw wykonać `git apply --check`, potem świadomie `git apply`. Eksport nie wymaga pushowania. Nie utworzono PR ani commita; dzięki temu pełna zmiana pozostaje do przejrzenia przed pierwszą kompilacją.
