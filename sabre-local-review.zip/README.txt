Base commit: 1cda8377047e083e002b30bc1037b58a02dbf6ff
LATEST VERSION: default camera sight retained; no custom meson optics.
Read raport/sabre_mining_04_widzenie_i_skanery.md for the latest changes.
Reports 01-03 document earlier stages; report 03 is marked historical.
Local uncommitted implementation; no GitHub publication.
Choose full-sabre-mining.patch OR the series 01 then 02. Do not apply both.
Check before applying: git apply --check <patch>
Then apply intentionally: git apply <patch>
For the series, apply 01 before checking/applying 02.
01 is the independent power bugfix with its DM test; it retains cost 2500.
02 adds Mining modules, cost 1000, UI, recipes, shared scanner markers, tests and icon.
Both export variants were verified against base files byte-for-byte.
DM compilation, game tests and TGUI build were NOT executed.

Scanner overlay isolation was reverted at user request. Sabre uses the existing mining_overlay type.
